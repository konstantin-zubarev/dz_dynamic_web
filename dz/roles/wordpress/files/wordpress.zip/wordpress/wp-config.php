<?php

define( 'DB_NAME', 'wordpress' );

define( 'DB_USER', 'wordpress' );

define( 'DB_PASSWORD', 'password' );

define( 'DB_HOST', 'localhost' );

define( 'DB_CHARSET', 'utf8mb4' );

define( 'DB_COLLATE', '' );

define( 'AUTH_KEY',         'FuTy%NL >(h.IUa+IadsYKu/G3B]v/#e`A*ViEV/(g((!:epPVs$wAbN2kRU~PxA' );
define( 'SECURE_AUTH_KEY',  '@j1L.&ild]&r]a9LH[04n,)FoR2;M,0)R2|)S3`MjC*k*xC39kv:ydp9*n*98B+c' );
define( 'LOGGED_IN_KEY',    'xuIP=|81Mh*Re`jIgow#EU>$e*V:a_PmJ2 XKc/;p*AZ@-$77gJFvOVX`r3<J>{v' );
define( 'NONCE_KEY',        '0ia/,}:y098isVkb.D]HC]|h0wp^FO!=;Gj,#c4Bp{ JcE#BV,nB#P9W9`NY|duh' );
define( 'AUTH_SALT',        'OIouw@^1b|hdd{uyeVwJ@MG^VwjIN+~6f*seeS!*,UmqIHB_e/WG]hC`M7%,O+TW' );
define( 'SECURE_AUTH_SALT', '+a)qpMyFSPy*mTo,O=cthU`!iQV(PcwI<c]s8O,X{QK:2fLP_7aJX+Q~n&=0ulEH' );
define( 'LOGGED_IN_SALT',   'Pf$XJ9WXX 7,NM.W$^x;>*FkEvy]}`@K`kiq7{35vHKY1l{uf2aE^d4yB/!&ZVcn' );
define( 'NONCE_SALT',       'MoYR4V5>b7M]5*Ea)E~U!.;61tq1v|HFTleU9#Y)F9EY6o/~Y&<S:]attRcAfE^E' );

$table_prefix = 'wp_';

define( 'WP_DEBUG', false );

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

require_once ABSPATH . 'wp-settings.php';
